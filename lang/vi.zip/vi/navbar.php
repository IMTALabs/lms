<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Navbar
    |--------------------------------------------------------------------------
    */

    'search_anything' => 'Search...',
    'home' => 'Home',
    'about_us' => 'About us',
    'contact' => 'Contact',
    'blog' => 'Blog',
    'terms' => 'Terms',
    'items' => 'Items',
    'menu' => 'Menu',
    'title' => 'Title',
    'start_a_live_class' => 'Start a new course',



];
