<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Footer (Translate to Vietnamese)
    |--------------------------------------------------------------------------
    */

    'join' => 'Tham gia',
    'join_us_today' => 'Tham gia ngay hôm nay',
    'subscribe_content' => '#Chúng tôi sẽ gửi những ưu đãi tốt nhất đến email của bạn.',
    'enter_email_here' => 'Nhập email của bạn vào đây',

];
